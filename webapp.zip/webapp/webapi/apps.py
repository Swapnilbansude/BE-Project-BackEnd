from django.apps import AppConfig


class WebapiConfig(AppConfig):
    name = 'webapi'
